// Organ.pde
import ddf.minim.ugens.*;

class Organ implements Instrument {
  Oscil osc;
  AudioOutput out;
  
  Organ(AudioOutput audioOut) {
    this.out = audioOut;
    
    // オルガンの基本音色（サイン波/WAVE.SINE）を作成
    osc = new Oscil(0, 0, Waves.SINE);
  }
  
  void play(float frequency, float durationSec) {
    this.osc.setFrequency(frequency);
    
    // 自分自身（this）を楽器としてplayNoteに引き渡す
    out.playNote(0.0, durationSec, this);
  }
  
  void noteOn(float dur) {
    osc.setAmplitude(0.4f); 
    osc.patch(out);        
  }
  
  void noteOff() {
    osc.unpatch(out);      
  }
}
