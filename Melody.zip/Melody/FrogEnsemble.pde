//FrogEnsemble

import ddf.minim.*;
import ddf.minim.ugens.*;

Minim minim;
AudioOutput out;

// 楽器のオブジェクトを準備
Trumpet trumpet;
Organ organ;

int bpm = 120;        
int currentIndex = 0; 
int nextNoteTime = 0; 

// ★外部・同期側からの合図を管理するフラグ（最初は再生しない）
boolean isPlaying = false; 

void setup() {
  size(500, 300); // 波形が見えやすいように少し縦を広げました
  
  minim = new Minim(this);
  out = minim.getLineOut();
  
  out = minim.getLineOut(Minim.STEREO, 2048);
  
  // 楽器の初期化
  trumpet = new Trumpet(out);
  organ = new Organ(out);
}

void draw() {
  background(30);
  fill(255);
  textSize(16);
  
  // 状態表示
  if (!isPlaying) {
    text("Waiting...", 20, 40);
    text("(test: click please)", 20, 70);
  } else {
    text("Playing...", 20, 40);
    text("Now Note:" + currentIndex + " / " + melody.length, 20, 70);
    
    // 合図が出ていれば、時間をチェックして次の音を鳴らす
    if (millis() > nextNoteTime) {
      playNextNote();
    }
  }
  
  // ★統合した【視覚効果（波形表示）】の処理
  // トランペットかオルガンかに関わらず、今スピーカーから鳴っている波を大体で描画します
  stroke(0, 255, 0); // 緑色の線
  strokeWeight(2);
  for (int i = 0; i < out.bufferSize() - 1; i++) {
    // 画面の下半分（y=200を中心に）にリアルタイムに波形を描く
    float x1 = map(i, 0, out.bufferSize(), 0, width);
    float x2 = map(i+1, 0, out.bufferSize(), 0, width);
    float y1 = 200 + out.left.get(i) * 50;
    float y2 = 200 + out.left.get(i+1) * 50;
    line(x1, y1, x2, y2);
  }
}

// テスト用：クリックされたら「同期の合図」があったとみなす
void mousePressed() {
  if (!isPlaying) {
    isPlaying = true;
    nextNoteTime = millis(); // すぐに1音目を鳴らす
  }
}

// 外部システム等からこの関数を呼び出すことで再生をスタートさせることも可能
void receiveSyncSignal() {
  isPlaying = true;
  nextNoteTime = millis();
}

void playNextNote() {

  if (currentIndex >= melody.length) {
    isPlaying = false; // 再生を停止して待機状態に戻す
    exit();
    return;            // この先の演奏処理をスキップする
  }
  
  float currentFreq = melody[currentIndex];
  float noteDurationMs = (60000.0 / bpm) * (4.0 / duration[currentIndex]);
  float noteDurationSec = noteDurationMs / 1000.0; // Minim用に秒に変換
  
  if (currentFreq > 0) {
    // ★ここで鳴らしたい方の楽器を呼び出す（現在はトランペット）
    // trumpet.play(currentFreq, noteDurationSec);
    organ.play(currentFreq, noteDurationSec); // オルガンにしたい場合はこちら
  }
  
  nextNoteTime = millis() + int(noteDurationMs);
  currentIndex++;
}

void stop() {
  out.close();
  minim.stop();
  super.stop();
}
