// Trumpet.pde
import ddf.minim.ugens.*;

// 「implements Instrument」を付けることで、playNoteに渡せるようになります
class Trumpet implements Instrument {
  Oscil osc;
  AudioOutput out;
  
  Trumpet(AudioOutput audioOut) {
    this.out = audioOut;
    
    // トランペットの基本音色（のこぎり波/WAVE.SAW）を作成
    // 初期の周波数は0、音量は0にしておきます
    osc = new Oscil(0, 0, Waves.SAW);
  }
  
  // 自作の演奏用関数
  void play(float frequency, float durationSec) {
    this.osc.setFrequency(frequency);
    
    // 自分自身（this）を楽器としてplayNoteに引き渡す
    out.playNote(0.0, durationSec, this);
  }
  
  // ★Minimのルール：音が鳴る瞬間に自動で呼ばれる関数
  void noteOn(float dur) {
    osc.setAmplitude(0.4f); // 音量をONにする
    osc.patch(out);        // スピーカーに接続
  }
  
  // ★Minimのルール：音が終わる瞬間に自動で呼ばれる関数
  void noteOff() {
    osc.unpatch(out);      // スピーカーから切断して音を消す
  }
}
