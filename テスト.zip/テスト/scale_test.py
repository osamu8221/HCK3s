import os
import numpy as np
from scipy.io import wavfile

# 1. 基準周波数設定
REFERENCE_PITCHES = {
    "C4": {"name": "ド", "freq": 261.63},
    "D4": {"name": "レ", "freq": 293.66},
    "E4": {"name": "ミ", "freq": 329.63},
    "F4": {"name": "ファ", "freq": 349.23},
    "G4": {"name": "ソ", "freq": 392.00},
    "A4": {"name": "ラ", "freq": 440.00},
    "B4": {"name": "シ", "freq": 493.88},
    "C5": {"name": "ド(高)", "freq": 523.25}
}

def analyze_pitch_autocorr(file_path):
    """
    librosaを使わず、自己相関法(Autocorrelation)を用いてピッチを計算する関数
    """
    try:
        # scipyで安全にWAVを読み込み
        sr, y = wavfile.read(file_path)
        
        # 浮動小数点数に変換し、モノラル化
        if y.dtype != np.float32:
            y = y.astype(np.float32) / np.iinfo(y.dtype).max
        if len(y.shape) > 1:
            y = np.mean(y, axis=1)
            
        # 簡易的な無音区間のトリミング（最大振幅の15%未満をカット）
        abs_y = np.abs(y)
        if np.max(abs_y) == 0:
            return 0.0
        y_trimmed = y[abs_y > (np.max(abs_y) * 0.15)]
        if len(y_trimmed) < 512:  # データが少なすぎたら元データを使用
            y_trimmed = y

        # 探索する周波数範囲の制限 (100Hz 〜 600Hz)
        # 周波数をサンプリングレートからラグ（ズレ）に変換
        lag_min = int(sr / 600)
        lag_max = int(sr / 100)
        
        # 自己相関を計算 (信号がどれくらい自分自身と重なるか)
        # librosa.yinの簡易自作版（AMDF / 自己相関ベース）
        corr = np.correlate(y_trimmed, y_trimmed, mode='full')
        # 後半の重なり部分だけを取得
        corr = corr[corr.size // 2:]
        
        # 指定範囲 (100Hz〜600Hzに対応するラグ) の中で最も高いピークを見つける
        if lag_max >= len(corr):
            lag_max = len(corr) - 1
            
        search_area = corr[lag_min:lag_max]
        if len(search_area) == 0:
            return 0.0
            
        best_lag = np.argmax(search_area) + lag_min
        
        # ラグから周波数(Hz)に変換
        detected_freq = sr / best_lag
        return float(detected_freq)
        
    except Exception as e:
        print(f"ファイルの読み込みまたは解析エラー: {e}")
        return 0.0

def calculate_cents_error(detected_freq, target_freq):
    if detected_freq <= 0:
        return float('inf')
    return 1200 * np.log2(detected_freq / target_freq)

def evaluate_scale(folder_path):
    print("==================================================")
    print("      音響妥当性評価: 音階一致度テストテスト開始   ")
    print("==================================================")
    
    success_count = 0
    available_count = 0
    
    for note_key, info in REFERENCE_PITCHES.items():
        file_name = f"{note_key}.wav"
        file_path = os.path.join(folder_path, file_name)
        
        if not os.path.exists(file_path):
            print(f"⚠️ スキップ: {file_name} が見つかりません。")
            continue
            
        available_count += 1
        detected_f0 = analyze_pitch_autocorr(file_path)
        
        if detected_f0 == 0.0:
            print(f"❌ {file_name} ({info['name']}): 音声を検出できませんでした。")
            continue
            
        cents_error = calculate_cents_error(detected_f0, info['freq'])
        
        # 判定ロジック (自己相関法は少しブレる可能性を考慮し、合格基準を±50セントとして評価)
        if abs(cents_error) <= 25:
            status = "✨ 非常に優秀 (Perfect Match)"
            success_count += 1
        elif abs(cents_error) <= 50:
            status = "✅ 合格 (Match)"
            success_count += 1
        else:
            status = "❌ 不合格 (Out of Tune)"
            
        print(f"🎵 音階名: {info['name']} ({note_key})")
        print(f"   - 基準周波数: {info['freq']:.2f} Hz")
        print(f"   - 録音周波数: {detected_f0:.2f} Hz")
        print(f"   - 音高のズレ: {cents_error:+.1f} セント")
        print(f"   - 判定      : {status}")
        print("-" * 50)
        
    print(f"\n📊 テスト結果: 存在する {available_count} 音中、{success_count} 音が一致度基準をクリアしました。")

if __name__ == "__main__":
    TARGET_FOLDER = "./recorded_waves" 
    if not os.path.exists(TARGET_FOLDER):
        os.makedirs(TARGET_FOLDER)
        print(f"フォルダ '{TARGET_FOLDER}' を作成しました。ファイルを配置してください。")
    else:
        evaluate_scale(TARGET_FOLDER)