// --- 楽器用Arduino (バイオリン担当 / カエルの歌は輪唱曲) ---
// ボード: Arduino UNO R4 WiFi (オンボードESP32-S3 / WiFiS3ライブラリ)
//
// 役割:
//   ・同期用Arduinoから【WiFi UDPブロードキャスト】で「再生の合図」と「テンポ情報(0〜4)」を受信
//   ・ino配列のメロディ(カエルの歌)を【この1台の中で3声部に重ねた輪唱】にして、
//     各ステップで鳴っている声部の音符を複数行 "Hz,ms" で Processing へ送信
//   ・Processing側は音色生成と再生(受信した音符を重ねて発音)・波形表示のみを担当する
//
// 接続:
//   USB Serial (115200) -> このボード専用PCの violin.pde (バイオリンの音色・再生・波形)
//     ※このinoは【バイオリン専用】。USBへは "Hz,ms" の音符行だけを送る(1ステップに
//       複数声部ぶん＝複数行送ることがある)。violin.pde はそれを受けて重ねて発音するだけ。
//     ※「Arduino 1台 につき PC 1台」。各楽器は自分のPCでProcessingを動かす。
//       USB(violin.pdeへ)とWiFi(同期受信)は独立して同時に動く。
//   WiFi (UDP) <- 同期用Arduinoのブロードキャスト (全受信機が同一データを受信)
//
// 同期用Arduino から受信するUDPペイロード(1バイト以上のコマンド列):
//   '0'〜'4' : テンポ情報。ino配列のbpmにリンクさせ、再生途中でも即時反映する。
//   'A'      : 音楽開始の合図。主旋律(声部0)を先頭から再生し始める。
//   'B'      : 輪唱開始の合図。2声目(声部1)がこの時点を先頭に入り、輪唱になる。
//   'X'      : 停止合図。
//
// ★輪唱(カエルの歌)について:
//   輪唱は「楽器ごとに声部を分ける」のではなく、【この1台の中で】2声部に重ねて作る。
//   → バイオリン1台だけで輪唱に聞こえる。全楽器が同じ輪唱を同時に演奏する。
//   ・'A'(音楽開始)で声部0がカエルの歌を先頭から再生(この時点は1声=ただの主旋律)。
//   ・'B'(輪唱開始)で声部1がメロディ先頭から入る。A→Bの間隔がそのまま輪唱のズレ量
//     になる(指揮者が好きなタイミングで2声目を入れられる、本来の輪唱の入り方)。
//   重なりはステップ数(=musical position)で管理するため、再生途中でテンポが
//   変わっても声部間のズレ(輪唱の間隔)は保たれる。

#include <WiFiS3.h>

// ============================================================
// WiFi設定: 同期Arduinoと全受信機を同じネットワーク(同一サブネット)に入れる。
//   同期Arduinoは 255.255.255.255:SYNC_UDP_PORT にコマンドをブロードキャストする。
// ============================================================
const char* WIFI_SSID = "YOUR_SSID";       // ★各自の環境に合わせる
const char* WIFI_PASS = "YOUR_PASSWORD";   // ★各自の環境に合わせる
const unsigned int SYNC_UDP_PORT = 50007;  // 同期Arduinoと一致させる

WiFiUDP udp;
char udpBuf[32];

// 書式: "音程(Hz),発音時間(ms)\n"
float melody[] = {
  523.2, 0.0, 587.3, 0.0, 659.2, 0.0, 698.4, 0.0,
  659.2, 0.0, 587.3, 0.0, 523.2, 0.0, 0.0, 0.0,
  659.2, 0.0, 698.4, 0.0, 784.0, 0.0, 880.0, 0.0,
  784.0, 0.0, 698.4, 0.0, 659.2, 0.0, 0.0, 0.0,
  523.2, 0.0, 0.0, 0.0,
  523.2, 0.0, 0.0, 0.0,
  523.2, 0.0, 0.0, 0.0,
  523.2, 0.0, 0.0, 0.0,
  523.2, 523.2, 587.3, 587.3, 659.2, 659.2, 698.4, 698.4,
  659.2, 0.0, 587.3, 0.0, 523.2, 0.0, 0.0, 0.0
};

int melodyLength = sizeof(melody) / sizeof(melody[0]);

// ============================================================
// 輪唱(カエルの歌): 1台の中で重ねる2声部
//   声部0 = 主旋律('A'からずっと再生)。
//   声部1 = 輪唱('B'を受けた時点を先頭に再生)。
//   声部1の位置 = playPos - roundStartPos なので、A→Bの間隔がカノンのズレ量になる。
// ============================================================
long playPos = 0;            // 'A'からの経過ステップ(0開始)=声部0の位置
bool roundActive = false;    // 'B'を受けたら true (2声目が入る)
long roundStartPos = 0;      // 'B'を受けた時点の playPos (声部1の先頭基準)

// ============================================================
// テンポ: 同期側から来る 0〜4 と、ino配列のbpmをリンクさせる
//   8分音符の長さ(ms) = 30000 / bpm
//   0:100bpm(300ms) 1:120bpm(250ms) 2:140bpm(214ms)
//   3:160bpm(188ms) 4:180bpm(167ms)
// ============================================================
const int NUM_TEMPOS = 5;
const int tempoBpmTable[NUM_TEMPOS] = {100, 120, 140, 160, 180};
int tempoStage = 1;        // 既定: index1 = 120bpm
int tempoMs = 250;         // 8分音符の長さ(ms) = 30000 / bpm

// 輪唱の開始合図が来るまでは待機状態
bool playing = false;

// 非ブロッキングなシーケンサ用タイマ
unsigned long lastStepTime = 0;

void setup() {
  Serial.begin(115200);     // -> このボード専用PCのProcessing

  connectWiFi();            // <- 同期Arduinoと同じネットワークに接続
  udp.begin(SYNC_UDP_PORT); // 同期ブロードキャストの受信開始
}

void loop() {
  // 同期Arduinoからの「テンポ変更」「開始/停止合図」を常時監視する
  handleSyncCommand();

  // --- マスタークロックによる再生 ---
  // delay()ではなくmillis()で刻むので、再生途中のテンポ変更に即応できる。
  if (playing) {
    unsigned long now = millis();
    if (now - lastStepTime >= (unsigned long)tempoMs) {
      lastStepTime = now;
      sendCurrentVoices();
      playPos++; // 次のステップへ(メロディは剰余でループ＝無限カノン)
    }
  }
}

// WiFi接続(接続できるまで待つ)
void connectWiFi() {
  int status = WL_IDLE_STATUS;
  while (status != WL_CONNECTED) {
    status = WiFi.begin(WIFI_SSID, WIFI_PASS);
    unsigned long t0 = millis();
    while (status != WL_CONNECTED && millis() - t0 < 8000) {
      delay(300);
      status = WiFi.status();
    }
  }
}

// 同期Arduinoからのコマンド受信(UDPブロードキャスト)
void handleSyncCommand() {
  int packetSize = udp.parsePacket();
  if (packetSize <= 0) return;

  int n = udp.read(udpBuf, sizeof(udpBuf));
  for (int i = 0; i < n; i++) {
    processSyncByte(udpBuf[i]);
  }
}

// 受信した1バイトのコマンドを処理
void processSyncByte(char c) {
  if (c >= '0' && c <= '4') {
    // テンポ情報(0〜4): ino配列のbpmにリンク。tempoMsを即時更新するので、
    // 次のステップから新しいテンポで再生され、途中変更が成立する。
    tempoStage = c - '0';
    tempoMs = 30000 / tempoBpmTable[tempoStage];

  } else if (c == 'A') {
    // 音楽開始の合図: 主旋律(声部0)を先頭から再生。輪唱はまだ。
    playing = true;
    playPos = 0;
    roundActive = false;
    lastStepTime = millis();

  } else if (c == 'B') {
    // 輪唱開始の合図: 2声目(声部1)がこの時点を先頭に入る。
    // A→Bの経過(playPos)がそのまま輪唱のズレ量になる。
    if (playing) {
      roundActive = true;
      roundStartPos = playPos;
    }

  } else if (c == 'X') {
    // 停止合図
    playing = false;
    roundActive = false;
  }
}

// この瞬間に鳴っている声部の音符を Processing へ送信する。
// 'B'以降は2声(主旋律＋輪唱)を送ることがあり、violin.pde が重ねて発音する=輪唱。
// 発音時間はテンポに比例(ゲート率80%)。
void sendCurrentVoices() {
  int durationMs = (int)(tempoMs * 0.8);

  // 声部0: 主旋律('A'からずっと)
  sendVoiceNote(playPos, durationMs);

  // 声部1: 輪唱('B'を受けた時点を先頭に)
  if (roundActive) {
    sendVoiceNote(playPos - roundStartPos, durationMs);
  }
}

// 指定位置の音符を1行 "Hz,ms" で送信(休符・未開始は送らない)
void sendVoiceNote(long pos, int durationMs) {
  if (pos < 0) return;
  float pitch = melody[pos % melodyLength];
  if (pitch <= 0.0) return;       // 休符は送らない
  Serial.print(pitch);
  Serial.print(",");
  Serial.println(durationMs);     // 改行付きで送信(1声部=1行)
}
