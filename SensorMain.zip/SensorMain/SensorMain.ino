// =============================================================
//  SensorMain.ino  ―  テンポ確認用テスト版
//
//  目的：
//    「センサ → 前処理 → ダウンビート検出 → BPM/テンポ段階」までが
//    実機でちゃんと動くかを、シリアルモニタで確認するための版。
//
//  この版ではまだ WiFi 送信（SensorSender）は入れていない。
//    → まず手元で「振ったら正しいBPM・段階が出るか」を確かめ、
//      それが安定してから通信を足す（段階的に作るための切り分け）。
//
//  確認のしかた：
//    1. これを書き込む
//    2. シリアルモニタ（9600bps）を開く
//    3. 指揮棒を2拍子で振る
//    4. 振り下ろすたびに interval / BPM / 段階 が表示されればOK
// =============================================================

#include "IMUReader.h"
#include "MotionFilter.h"
#include "BeatDetector.h"
#include "DownbeatDetector.h"
#include "TempoCalculator.h"

IMUReader        imu;             // センサ読み取り
MotionFilter     filter;          // 重力除去・平滑化
BeatDetector     beatDetector;    // 1拍区間の「強さ」管理（強弱演出用・テンポには未使用）
DownbeatDetector downbeatDetector;// 振り下ろし検出＋間隔測定
TempoCalculator  tempo;           // 間隔→BPM→3段階

const unsigned long SAMPLE_INTERVAL = 10;  // 10msごとにセンサを読む（100Hz）
unsigned long lastSampleTime = 0;

bool isStarted = false;  // 最初の振り下ろしが来たか（STARTの代わりの目印）

void setup() {
  Serial.begin(9600);

  imu.begin();

  // ----- ダウンビート検知の設定（★実機で振って調整する値）-----
  downbeatDetector.setAxis(0);                  // gx（実測で確認した軸に合わせる）
  downbeatDetector.setDirection(-1);            // 振り下ろしでgxがマイナスなら-1
  downbeatDetector.setDownGyroThreshold(80.0);  // 振り下ろしの強さの下限
  downbeatDetector.setSideRatio(1.2);           // 横振りを除外する強さ
  downbeatDetector.setMinInterval(600);         // 連続検知を防ぐ最小間隔[ms]
                                                // ※300だと1回の振りの「揺り戻し」を
                                                //   二度検出してしまう（約306msの幽霊検出）。
                                                //   600に上げて1振り=1検出にする。

  // ----- テンポ計算の設定（★必要なら実測で調整）-----
  tempo.setBeatsPerMeasure(2);                  // 2拍子
  tempo.setThresholds(100.0, 130.0);            // 100未満SLOW / 130以上FAST
                                                // SLOWを出しやすくするため境界を80→100に上げた。
                                                // 100=間隔1200ms（約1.2秒）でSLOWになる。
                                                // もっと出しやすく→105まで上げてOK。
                                                // （ただし108以上にすると普通の振りもSLOWになるので注意）

  // シリアルモニタの見出し（CSVとして表計算に貼れる）
  Serial.println("time,interval,bpm,level");
}

void loop() {
  unsigned long now = millis();

  // 10msごとにだけ処理する
  if (now - lastSampleTime < SAMPLE_INTERVAL) {
    return;
  }
  lastSampleTime = now;

  // --- ① センサから読む ---
  IMUData data = imu.readIMU();

  // --- ② 前処理（重力除去 → 合成 → 平滑化）---
  IMUData filterData  = filter.removeGravity(data);
  float   motion      = filter.calcMotion(filterData);
  float   smoothMotion = filter.smooth(motion);

  // --- ③ ダウンビート（振り下ろし）を検出 ---
  bool downbeatDetected = downbeatDetector.detectDownbeat(data, now);

  // --- ④ 強さ(peak)を管理（テンポには使わないが残しておく）---
  beatDetector.update(smoothMotion, downbeatDetected);

  // --- ⑤ 振り下ろしが来た時だけ、テンポを計算して表示 ---
  if (downbeatDetected) {
    unsigned long itv = downbeatDetector.getInterval();

    if (!isStarted) {
      // 最初の振り下ろし＝演奏開始の合図（本番はここでSTARTを送る）
      isStarted = true;
      Serial.println(">> START (最初の振り下ろし)");
    }

    // 間隔をテンポ計算に渡す。
    // 最初の拍は itv==0 なので update は false を返す（BPMはまだ出ない）。
    if (tempo.update(itv)) {
      TempoLevel lv = tempo.getLevel();
      const char* name = (lv == TEMPO_SLOW)   ? "SLOW" :
                         (lv == TEMPO_NORMAL) ? "NORMAL" : "FAST";

      // CSV形式：時刻,間隔,BPM,段階
      Serial.print(now);          Serial.print(",");
      Serial.print(itv);          Serial.print(",");
      Serial.print(tempo.getBPM()); Serial.print(",");
      Serial.println(name);
    }
  }
}
